import tkinter as tk
from tkinter import messagebox, scrolledtext

class Node:
    def __init__(self, key):
        self.left = None
        self.right = None
        self.val = key

class BinaryTree:
    def __init__(self):
        self.root = None

    def insert(self, key):
        if self.root is None:
            self.root = Node(key)
        else:
            self._insert_recursive(self.root, key)

    def _insert_recursive(self, node, key):
        if key < node.val:
            if node.left is None:
                node.left = Node(key)
            else:
                self._insert_recursive(node.left, key)
        else:
            if node.right is None:
                node.right = Node(key)
            else:
                self._insert_recursive(node.right, key)

    def inorder(self, node):
        return self.inorder(node.left) + [node.val] + self.inorder(node.right) if node else []

    def preorder(self, node):
        return [node.val] + self.preorder(node.left) + self.preorder(node.right) if node else []

    def postorder(self, node):
        return self.postorder(node.left) + self.postorder(node.right) + [node.val] if node else []

    def delete(self, key):
        self.root = self._delete_recursive(self.root, key)

    def _delete_recursive(self, node, key):
        if not node:
            return node
        if key < node.val:
            node.left = self._delete_recursive(node.left, key)
        elif key > node.val:
            node.right = self._delete_recursive(node.right, key)
        else:
            if not node.left:
                return node.right
            elif not node.right:
                return node.left
            min_larger_node = self._min_value_node(node.right)
            node.val = min_larger_node.val
            node.right = self._delete_recursive(node.right, min_larger_node.val)
        return node

    def _min_value_node(self, node):
        current = node
        while current.left:
            current = current.left
        return current

class BinaryTreeGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.tree = BinaryTree()
        self.root.title("Binary Tree Implementation")
        self.root.geometry("1600x1200")
        self.root.configure(bg="#F0F8FF")

        # Headline
        heading_label1 = tk.Label(root, text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
                                   font=("Helvetica", 24, "bold"), bg="#F0F8FF", fg="#0000FF")
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(root, text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
                                   font=("Helvetica", 18), bg="#F0F8FF", fg="#000000")
        heading_label2.pack(pady=(0, 5))

        task_label = tk.Label(root, text="7. Binary Tree Operations (Insert, Delete, Traverse)",
                               font=("Helvetica", 16), bg="#F0F8FF", fg="#000000")
        task_label.pack(pady=(0, 20))

        # Entry frame
        entry_frame = tk.Frame(root, bg="#F0F8FF")
        entry_frame.pack(pady=10)

        value_label = tk.Label(entry_frame, text="Enter Value:", bg="#F0F8FF", font=("Helvetica", 12))
        value_label.grid(row=0, column=0, padx=5, pady=5)

        self.entry_value = tk.Entry(entry_frame, font=("Helvetica", 16))
        self.entry_value.grid(row=0, column=1, padx=5, pady=5)

        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=10)

        insert_button = tk.Button(button_frame, text="Insert", command=self.insert_item,
                                   font=("Helvetica", 16), bg="#87CEEB", fg="black", width=10)
        insert_button.grid(row=0, column=0, padx=5)

        delete_button = tk.Button(button_frame, text="Delete", command=self.delete_item,
                                   font=("Helvetica", 16), bg="#FF6347", fg="white", width=10)
        delete_button.grid(row=0, column=1, padx=5)

        traverse_frame = tk.Frame(root, bg="#F0F8FF")
        traverse_frame.pack(pady=10)

        inorder_button = tk.Button(traverse_frame, text="Inorder", command=self.traverse_inorder,
                                    font=("Helvetica", 16), bg="#32CD32", fg="white", width=10)
        inorder_button.grid(row=0, column=0, padx=5)

        preorder_button = tk.Button(traverse_frame, text="Preorder", command=self.traverse_preorder,
                                     font=("Helvetica", 16), bg="#FFA500", fg="white", width=10)
        preorder_button.grid(row=0, column=1, padx=5)

        postorder_button = tk.Button(traverse_frame, text="Postorder", command=self.traverse_postorder,
                                      font=("Helvetica", 16), bg="#00CED1", fg="white", width=10)
        postorder_button.grid(row=0, column=2, padx=5)

        display_tree_button = tk.Button(root, text="Display Tree", command=self.open_tree_window,
                                         font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        display_tree_button.pack(pady=10)

        info_button = tk.Button(root, text="Info", command=self.open_info_window,
                                font=("Helvetica", 16), bg="#FFD700", fg="black", width=10)
        info_button.pack(pady=10)

        self.output = tk.Text(root, width=50, height=10, font=("Helvetica", 12), borderwidth=2, relief="groove")
        self.output.pack(pady=10)

        back_button = tk.Button(root, text="Back", command=back_callback,
                                font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

    def insert_item(self):
        value = self.entry_value.get()
        if value.isdigit():
            self.tree.insert(int(value))
            self.entry_value.delete(0, tk.END)
            self.display_tree()
        else:
            messagebox.showwarning("Input Error", "Please enter a valid integer.")

    def delete_item(self):
        value = self.entry_value.get()
        if value.isdigit():
            self.tree.delete(int(value))
            self.entry_value.delete(0, tk.END)
            self.display_tree()
        else:
            messagebox.showwarning("Input Error", "Please enter a valid integer.")

    def traverse_inorder(self):
        inorder = self.tree.inorder(self.tree.root)
        self.output.delete(1.0, tk.END)
        self.output.insert(tk.END, "Inorder Traversal: " + ", ".join(map(str, inorder)) + "\n")

    def traverse_preorder(self):
        preorder = self.tree.preorder(self.tree.root)
        self.output.delete(1.0, tk.END)
        self.output.insert(tk.END, "Preorder Traversal: " + ", ".join(map(str, preorder)) + "\n")

    def traverse_postorder(self):
        postorder = self.tree.postorder(self.tree.root)
        self.output.delete(1.0, tk.END)
        self.output.insert(tk.END, "Postorder Traversal: " + ", ".join(map(str, postorder)) + "\n")

    def display_tree(self):
        self.output.delete(1.0, tk.END)
        inorder = self.tree.inorder(self.tree.root)
        self.output.insert(tk.END, "Current Tree (Inorder): " + ", ".join(map(str, inorder)) + "\n")

    def open_tree_window(self):
        # Create a new window for the tree display
        tree_window = tk.Toplevel(self.root)
        tree_window.title("Binary Tree Display")
        tree_window.geometry("800x600")  # Set window size
        tree_window.configure(bg="#F0F8FF")

        canvas = tk.Canvas(tree_window, width=800, height=600, bg="#F0F8FF")
        canvas.pack(pady=20)

        self.draw_tree(canvas)

    def draw_tree(self, canvas):
        canvas.delete("all")  # Clear the canvas
        self._draw_node(self.tree.root, 400, 30, 200, canvas)  # Center the tree

    def _draw_node(self, node, x, y, offset, canvas):
        if node:
            canvas.create_oval(x - 20, y - 20, x + 20, y + 20, fill="lightblue")
            canvas.create_text(x, y, text=str(node.val), font=("Helvetica", 12, "bold"))
            if node.left:
                canvas.create_line(x, y + 20, x - offset, y + 70)
                self._draw_node(node.left, x - offset, y + 70, offset // 2, canvas)
            if node.right:
                canvas.create_line(x, y + 20, x + offset, y + 70)
                self._draw_node(node.right, x + offset, y + 70, offset // 2, canvas)

    def open_info_window(self):
        # Create a new window for binary tree information
        info_window = tk.Toplevel(self.root)
        info_window.title("Binary Tree Information")
        info_window.geometry("1600x1200")
        info_window.configure(bg="#F0F8FF")

        info_content = (
            "Binary Tree Information:\n\n"
            "1. Definition:\n"
            "   A binary tree is a tree data structure in which each node has at most two children, "
            "referred to as the left child and the right child.\n\n"
            "2. Properties:\n"
            "   - A binary tree with n nodes has at most n-1 edges.\n"
            "   - The maximum number of nodes at level l is 2^l, where level is 0-based.\n"
            "   - The maximum number of nodes in a binary tree of height h is 2^(h+1) - 1.\n\n"
            "3. Operations:\n"
            "   - Insertion: Adding a new node to the tree in a proper position.\n"
            "   - Deletion: Removing a node from the tree while maintaining the binary tree properties.\n"
            "   - Traversal: Visiting all the nodes in a specific order (Inorder, Preorder, Postorder).\n\n"
            "4. Traversal Methods:\n"
            "   - Inorder Traversal (Left, Root, Right): Outputs nodes in non-decreasing order for BSTs.\n"
            "   - Preorder Traversal (Root, Left, Right): Used to create a copy of the tree.\n"
            "   - Postorder Traversal (Left, Right, Root): Used to delete the tree.\n\n"
            "5. Graphical Representation:\n"
            "   - The tree is displayed using a canvas where each node is represented as a circle.\n"
            "   - Lines are drawn to connect parent nodes to their children.\n"
            "   - The tree is arranged so that each level is drawn at increasing y-coordinates."
        )

        # ScrolledText for displaying binary tree information
        info_text = scrolledtext.ScrolledText(info_window, font=("Helvetica", 12), bg="#F0F8FF", fg="green", wrap=tk.WORD, height=25)
        info_text.pack(expand=True, fill='both', padx=10, pady=10)

        info_text.insert(tk.END, info_content)
        info_text.config(state=tk.DISABLED)

        back_button = tk.Button(info_window, text="Back", command=info_window.destroy,
                                font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

# Main execution
if __name__ == "__main__":
    root = tk.Tk()
    app = BinaryTreeGUI(root, lambda: root.destroy())
    root.mainloop()
