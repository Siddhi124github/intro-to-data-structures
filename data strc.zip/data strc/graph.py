import tkinter as tk
from tkinter import messagebox, simpledialog
import networkx as nx
import matplotlib.pyplot as plt

class Graph:
    def __init__(self):
        self.graph = nx.Graph()

    def add_vertex(self, vertex):
        self.graph.add_node(vertex)

    def add_edge(self, u, v):
        self.graph.add_edge(u, v)

    def remove_vertex(self, vertex):
        self.graph.remove_node(vertex)

    def remove_edge(self, u, v):
        self.graph.remove_edge(u, v)

    def draw_graph(self):
        plt.clf()  # Clear the current figure
        nx.draw(self.graph, with_labels=True, node_color='lightblue', node_size=2000, font_size=16, font_color='black')
        plt.title("Graph Visualization")
        plt.show()

class GraphGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.graph = Graph()
        self.root.title("Graph Implementation")
        self.root.attributes('-fullscreen', True)  # Make the window fullscreen
        self.root.configure(bg="#F0F8FF")

        # Headline
        heading_label1 = tk.Label(
            root,
            text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
            font=("Helvetica", 24, "bold"),
            bg="#F0F8FF",
            fg="#0000FF"
        )
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(
            root,
            text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
            font=("Helvetica", 18),
            bg="#F0F8FF",
            fg="#000000"
        )
        heading_label2.pack(pady=(0, 5))

        task_label = tk.Label(
            root,
            text="Graph Implementation: Create, Insert, Delete Vertices",
            font=("Helvetica", 16),
            bg="#F0F8FF",
            fg="#000000"
        )
        task_label.pack(pady=(0, 20))

        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=10)

        add_vertex_button = tk.Button(button_frame, text="Add Vertex", command=self.add_vertex, font=("Helvetica", 16), bg="#87CEEB", fg="black", width=15)
        add_vertex_button.grid(row=0, column=0, padx=5)

        add_edge_button = tk.Button(button_frame, text="Add Edge", command=self.add_edge, font=("Helvetica", 16), bg="#87CEEB", fg="black", width=15)
        add_edge_button.grid(row=0, column=1, padx=5)

        remove_vertex_button = tk.Button(button_frame, text="Remove Vertex", command=self.remove_vertex, font=("Helvetica", 16), bg="#FF6347", fg="white", width=15)
        remove_vertex_button.grid(row=1, column=0, padx=5)

        remove_edge_button = tk.Button(button_frame, text="Remove Edge", command=self.remove_edge, font=("Helvetica", 16), bg="#FF6347", fg="white", width=15)
        remove_edge_button.grid(row=1, column=1, padx=5)

        display_graph_button = tk.Button(button_frame, text="Display Graph", command=self.display_graph, font=("Helvetica", 16), bg="#32CD32", fg="white", width=15)
        display_graph_button.grid(row=2, column=0, padx=5)

        back_button = tk.Button(root, text="Back", command=back_callback, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

    def add_vertex(self):
        vertex = simpledialog.askstring("Input", "Enter vertex name:")
        if vertex:
            self.graph.add_vertex(vertex)
            messagebox.showinfo("Success", f"Vertex '{vertex}' added.")

    def add_edge(self):
        edge = simpledialog.askstring("Input", "Enter edge (u,v):")
        if edge:
            u, v = edge.split(',')
            self.graph.add_edge(u.strip(), v.strip())
            messagebox.showinfo("Success", f"Edge '{u.strip()} - {v.strip()}' added.")

    def remove_vertex(self):
        vertex = simpledialog.askstring("Input", "Enter vertex name to remove:")
        if vertex:
            self.graph.remove_vertex(vertex)
            messagebox.showinfo("Success", f"Vertex '{vertex}' removed.")

    def remove_edge(self):
        edge = simpledialog.askstring("Input", "Enter edge to remove (u,v):")
        if edge:
            u, v = edge.split(',')
            self.graph.remove_edge(u.strip(), v.strip())
            messagebox.showinfo("Success", f"Edge '{u.strip()} - {v.strip()}' removed.")

    def display_graph(self):
        if not self.graph.graph.nodes:
            messagebox.showwarning("Empty Graph", "No vertices to display.")
        else:
            self.graph.draw_graph()

if __name__ == "__main__":
    root = tk.Tk()
    app = GraphGUI(root, lambda: root.destroy())  # Pass a simple back callback
    root.mainloop()
