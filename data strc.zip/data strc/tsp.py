import tkinter as tk
from tkinter import messagebox, scrolledtext
from itertools import permutations
import networkx as nx
import matplotlib.pyplot as plt

# Function to calculate the total distance for a given path
def calculate_total_distance(path, distance_matrix):
    total_distance = 0
    for i in range(len(path) - 1):
        total_distance += distance_matrix[path[i]][path[i + 1]]
    total_distance += distance_matrix[path[-1]][path[0]]  # Return to the starting point
    return total_distance

# Function to solve TSP using brute force
def solve_tsp(distance_matrix, num_cities, start_city):
    cities = list(range(num_cities))
    min_distance = float('inf')
    best_path = []
    all_paths = []

    for path in permutations(cities):
        if path[0] != start_city:
            continue  # Ensure the path starts from the selected start_city
        current_distance = calculate_total_distance(path, distance_matrix)
        all_paths.append((path, current_distance))
        if current_distance < min_distance:
            min_distance = current_distance
            best_path = path

    return best_path, min_distance, all_paths

# Function to create the graph (visual representation) of the cities and distances
def draw_graph(city_names, distance_matrix):
    G = nx.DiGraph()  # Use a directed graph for non-symmetric distances
    for i, city in enumerate(city_names):
        G.add_node(city)

    for i in range(len(city_names)):
        for j in range(len(city_names)):
            if i != j:
                weight = distance_matrix[i][j]
                # Check if the distance matrix is asymmetric (i.e., distance from i to j is not the same as from j to i)
                if distance_matrix[i][j] != distance_matrix[j][i]:
                    G.add_edge(city_names[i], city_names[j], weight=weight)
                    G.add_edge(city_names[j], city_names[i], weight=distance_matrix[j][i])
                else:
                    # If it's symmetric, just add one edge
                    G.add_edge(city_names[i], city_names[j], weight=weight)

    # Draw the graph using NetworkX and Matplotlib
    pos = nx.spring_layout(G)
    labels = nx.get_edge_attributes(G, 'weight')
    plt.figure(figsize=(8, 6))
    nx.draw(G, pos, with_labels=True, node_size=2000, node_color='skyblue', font_size=10, font_weight='bold')
    nx.draw_networkx_edge_labels(G, pos, edge_labels=labels)
    plt.title('City Distance Graph')
    plt.show()

class TSPGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.root.title("Travelling Salesman Problem - Siddhi Naik S095")
        self.root.geometry("1600x1200")  # Fixed the typo here
        self.root.configure(bg="#F0F8FF")

        # Heading
        heading_label1 = tk.Label(root, text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE", font=("Helvetica", 24, "bold"), bg="#F0F8FF", fg="#0000FF")
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(root, text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT", font=("Helvetica", 18), bg="#F0F8FF", fg="#000000")
        heading_label2.pack(pady=(0, 5))

        # New white heading below the project title
        heading_label3 = tk.Label(root, text="Travelling Salesman Problem", font=("Helvetica", 20, "bold"), bg="white", fg="#0000FF")
        heading_label3.pack(pady=(10, 20))

        task_label = tk.Label(root, text="Enter the number of cities:", font=("Helvetica", 16), bg="#F0F8FF", fg="#000000")
        task_label.pack(pady=(0, 20))

        # Number of cities input
        self.entry_num_cities = tk.Entry(root, width=10, font=("Helvetica", 12))
        self.entry_num_cities.pack()

        # Solve button
        generate_button = tk.Button(root, text="Generate Input Fields", command=self.create_input_fields, font=("Helvetica", 14), bg="lightblue", height=2, width=20)
        generate_button.pack(pady=20)

        # Info button
        info_button = tk.Button(root, text="Info", command=self.show_info, font=("Helvetica", 14), bg="#B0E0E6", height=2, width=20)
        info_button.pack(pady=10)

        # Back button
        back_button = tk.Button(root, text="Back", command=back_callback, font=("Helvetica", 14), bg="#B0E0E6", height=2, width=20)
        back_button.pack(pady=10)

        # Result label
        self.result_label = tk.Label(root, text="", font=("Helvetica", 12), fg="green", bg="#F0F8FF")
        self.result_label.pack(pady=10)

    def create_input_fields(self):
        try:
            num_cities = int(self.entry_num_cities.get())
            if num_cities < 2:
                messagebox.showerror("Error", "Number of cities must be 2 or more.")
                return
        except ValueError:
            messagebox.showerror("Error", "Please enter a valid number of cities.")
            return

        # Remove previous input fields if they exist
        for widget in self.root.winfo_children():
            if isinstance(widget, tk.Frame):
                widget.destroy()

        self.city_frame = tk.Frame(self.root, bg="#F0F8FF")
        self.city_frame.pack(pady=10)

        # City names input
        self.city_entries = []
        for i in range(num_cities):
            city_label = tk.Label(self.city_frame, text=f"Enter City {i + 1} Name:", font=("Helvetica", 12))
            city_label.grid(row=i, column=0, padx=10, pady=5)
            city_entry = tk.Entry(self.city_frame, width=20, font=("Helvetica", 12))
            city_entry.grid(row=i, column=1, padx=10, pady=5)
            self.city_entries.append(city_entry)

        # Distance matrix input
        distance_label = tk.Label(self.root, text="Enter distances between cities (in km):", font=("Helvetica", 12))
        distance_label.pack(pady=10)

        self.distance_entries = []
        for i in range(num_cities):
            row_entries = []
            for j in range(num_cities):
                entry = tk.Entry(self.city_frame, width=5, font=("Helvetica", 12))
                entry.grid(row=i, column=j + 2, padx=5, pady=5)
                row_entries.append(entry)
            self.distance_entries.append(row_entries)

        # Entry for starting city
        self.start_city_entry = tk.Entry(self.root, width=20, font=("Helvetica", 12))
        self.start_city_entry.pack(pady=(10, 5))
        self.start_city_entry.insert(0, "Enter Starting City Name")

        # Solve button
        solve_button = tk.Button(self.root, text="Solve TSP", command=self.on_solve, font=("Helvetica", 14), bg="lightgreen", height=2, width=20)
        solve_button.pack(pady=20)

    def on_solve(self):
        num_cities = len(self.city_entries)
        city_names = []
        distance_matrix = []

        # Get city names
        for i in range(num_cities):
            city_name = self.city_entries[i].get().strip()
            if not city_name:
                messagebox.showerror("Error", f"Please enter a valid name for City {i + 1}.")
                return
            city_names.append(city_name)

        # Get distances between cities
        try:
            for i in range(num_cities):
                row = []
                for j in range(num_cities):
                    if i == j:
                        row.append(0.0)  # Distance to itself is 0
                    else:
                        distance = float(self.distance_entries[i][j].get())  # Change to float
                        row.append(distance)
                distance_matrix.append(row)
        except ValueError:
            messagebox.showerror("Error", "Please enter valid distances.")
            return

        # Get the starting city from the entry box
        start_city_name = self.start_city_entry.get().strip()
        if start_city_name not in city_names:
            messagebox.showerror("Error", "Please enter a valid starting city name from the list.")
            return
        start_city_index = city_names.index(start_city_name)

        # Solve the TSP problem
        best_path, min_distance, all_paths = solve_tsp(distance_matrix, num_cities, start_city_index)

        # Display the result
        result_text = f"Shortest Path: {' -> '.join(map(lambda x: city_names[x], best_path))} -> {city_names[best_path[0]]}\n"
        result_text += f"Minimum Distance: {min_distance:.2f} km\n"
        result_text += "All Possible Routes:\n"

        for path, distance in all_paths:
            route = ' -> '.join(map(lambda x: city_names[x], path)) + f" -> {city_names[path[0]]} ({distance:.2f} km)"
            result_text += route + "\n"

        self.result_label.config(text=result_text)

        # Draw the graph of the cities and distances
        draw_graph(city_names, distance_matrix)

    def show_info(self):
        # Create a new info window
        info_window = tk.Toplevel(self.root)
        info_window.title("Travelling Salesman Problem Information")
        info_window.geometry("1600x1000")
        info_window.configure(bg="#F0F8FF")

        # Content to display
        info_content = (
            "Travelling Salesman Problem (TSP):\n\n"
            "The Traveling Salesman Problem is a classic optimization problem in computer science.\n"
            "It involves finding the shortest possible route that visits a set of cities and returns to the origin city.\n"
            "The problem can be solved using brute force methods (checking all permutations),\n"
            "but this becomes impractical for large numbers of cities due to factorial growth.\n"
            "\nKey Points:\n"
            "- The distance matrix must be symmetric for undirected graphs (i.e., distance from A to B is the same as from B to A).\n"
            "- For directed graphs or asymmetric distance matrices, different distances can be defined for each direction.\n"
            "- The TSP is NP-hard, meaning that no polynomial-time solution is known.\n"
            "\nSolutions may include heuristics or approximations for larger datasets."
        )

        # ScrolledText for displaying TSP information
        info_text = scrolledtext.ScrolledText(info_window, font=("Helvetica", 12), bg="#F0F8FF", fg="green", wrap=tk.WORD, height=25)
        info_text.pack(expand=True, fill='both', padx=10, pady=10)

        info_text.insert(tk.END, info_content)
        info_text.config(state=tk.DISABLED)  # Make it read-only

        # Back button to close info window
        back_button = tk.Button(info_window, text="Back", command=info_window.destroy, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

if __name__ == "__main__":
    root = tk.Tk()
    app = TSPGUI(root, lambda: root.destroy())  # Pass a simple back callback
    root.mainloop()
