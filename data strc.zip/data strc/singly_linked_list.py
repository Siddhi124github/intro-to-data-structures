import tkinter as tk
from tkinter import messagebox, scrolledtext

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class SinglyLinkedList:
    def __init__(self):
        self.head = None

    def is_empty(self):
        return self.head is None

    def insert(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node

    def delete(self, data):
        current = self.head
        previous = None
        while current is not None:
            if current.data == data:
                if previous is None:
                    self.head = current.next
                else:
                    previous.next = current.next
                return True
            previous = current
            current = current.next
        return False

    def traverse(self):
        elements = []
        current = self.head
        while current:
            elements.append(current.data)
            current = current.next
        return elements

    def search(self, data):
        current = self.head
        while current:
            if current.data == data:
                return True
            current = current.next
        return False

    def size(self):
        count = 0
        current = self.head
        while current:
            count += 1
            current = current.next
        return count

class SinglyLinkedListGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.linked_list = SinglyLinkedList()
        self.root.title("Singly Linked List Implementation")
        self.root.geometry("1600x1200")  # Set window size
        self.root.configure(bg="#F0F8FF")

        # Headline
        heading_label1 = tk.Label(
            root,
            text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
            font=("Helvetica", 24, "bold"),
            bg="#F0F8FF",
            fg="#0000FF"
        )
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(
            root,
            text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
            font=("Helvetica", 18),
            bg="#F0F8FF",
            fg="#000000"
        )
        heading_label2.pack(pady=(0, 5))

        task_label = tk.Label(
            root,
            text="3. Write a program to implement Singly Linked List with insertion, deletion operations",
            font=("Helvetica", 16),
            bg="#F0F8FF",
            fg="#000000"
        )
        task_label.pack(pady=(0, 20))

        self.entry = tk.Entry(root, font=("Helvetica", 16))
        self.entry.pack(pady=(10, 10))

        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=10)

        insert_button = tk.Button(button_frame, text="Insert", command=self.insert_item, font=("Helvetica", 16), bg="#87CEEB", fg="black", width=10)
        insert_button.grid(row=0, column=0, padx=5)

        delete_button = tk.Button(button_frame, text="Delete", command=self.delete_item, font=("Helvetica", 16), bg="#FF6347", fg="white", width=10)
        delete_button.grid(row=0, column=1, padx=5)

        search_button = tk.Button(button_frame, text="Search", command=self.search_item, font=("Helvetica", 16), bg="#FFD700", fg="black", width=10)
        search_button.grid(row=0, column=2, padx=5)

        size_button = tk.Button(button_frame, text="Size", command=self.display_size, font=("Helvetica", 16), bg="#32CD32", fg="white", width=10)
        size_button.grid(row=0, column=3, padx=5)

        info_button = tk.Button(button_frame, text="Info", command=self.open_info_window, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        info_button.grid(row=0, column=4, padx=5)

        self.output = tk.Text(root, width=50, height=10, font=("Helvetica", 12), borderwidth=2, relief="groove")
        self.output.pack(pady=10)

        self.canvas = tk.Canvas(root, width=600, height=200, bg="#F0F8FF", highlightthickness=0)
        self.canvas.pack(pady=(10, 20))

        back_button = tk.Button(root, text="Back", command=back_callback, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

    def insert_item(self):
        data = self.entry.get()
        if data:
            self.linked_list.insert(data)
            self.entry.delete(0, tk.END)
            self.display_list()
            self.update_visual()  # Update visual representation
        else:
            messagebox.showwarning("Input Error", "Please enter a value to insert.")

    def delete_item(self):
        data = self.entry.get()
        if data:
            if self.linked_list.delete(data):
                self.entry.delete(0, tk.END)
                self.display_list()
                messagebox.showinfo("Deleted", f"Deleted: {data}")
                self.update_visual()  # Update visual representation
            else:
                messagebox.showwarning("Delete Error", f"{data} not found in the list.")
        else:
            messagebox.showwarning("Input Error", "Please enter a value to delete.")

    def search_item(self):
        data = self.entry.get()
        if data:
            found = self.linked_list.search(data)
            if found:
                messagebox.showinfo("Search Result", f"Value '{data}' found in the list.")
            else:
                messagebox.showwarning("Search Result", f"Value '{data}' not found in the list.")
        else:
            messagebox.showwarning("Input Error", "Please enter a value to search.")

    def display_size(self):
        size = self.linked_list.size()
        self.output.delete(1.0, tk.END)
        self.output.insert(tk.END, f"List size: {size}\n")
        self.update_visual()  # Update visual representation

    def display_list(self):
        self.output.delete(1.0, tk.END)
        if self.linked_list.is_empty():
            self.output.insert(tk.END, "List is empty.")
        else:
            elements = self.linked_list.traverse()
            self.output.insert(tk.END, "Current List: " + " -> ".join(elements) + "\n")
        self.update_visual()  # Update visual representation after displaying the list

    def open_info_window(self):
        info_window = tk.Toplevel(self.root)
        info_window.title("Singly Linked List Information")
        info_window.geometry("1600x1000")
        info_window.configure(bg="#F0F8FF")

        info_content = (
            "Singly Linked List Information:\n\n"
            "1. Definition: A singly linked list is a fundamental data structure in computer science and programming. "
            "It consists of nodes where each node contains a data field and a reference to the next node in the list. "
            "The last node points to null, indicating the end of the list.\n\n"
            "2. Basic Operations:\n"
            "   - Insert: Add a new node at the beginning of the list.\n"
            "   - Delete: Remove a node with a specific value from the list.\n"
            "   - Search: Search for a specific value in the list.\n"
            "   - Size: Get the number of nodes in the list.\n"
            "3. Advantages:\n"
            "   - Dynamic size: The list can grow and shrink as needed.\n"
            "   - Efficient insertion and deletion from the beginning.\n"
            "4. Disadvantages:\n"
            "   - No direct access to elements (must traverse from the head).\n"
            "   - Extra memory for pointers."
        )

        # ScrolledText for displaying linked list information
        info_text = scrolledtext.ScrolledText(info_window, font=("Helvetica", 12), bg="#F0F8FF", fg="green", wrap=tk.WORD, height=25)
        info_text.pack(expand=True, fill='both', padx=10, pady=10)

        info_text.insert(tk.END, info_content)
        info_text.config(state=tk.DISABLED)  # Make it read-only

        back_button = tk.Button(info_window, text="Back", command=info_window.destroy, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

    def update_visual(self):
        self.canvas.delete("all")  # Clear the canvas
        current = self.linked_list.head
        x = 50  # Starting x position
        y = 100  # Y position

        # Show head pointer
        self.canvas.create_text(30, 30, text="Head", fill="blue", font=("Helvetica", 14))

        if self.linked_list.is_empty():
            self.canvas.create_text(300, 100, text="List is empty", fill="red", font=("Helvetica", 14))
        else:
            while current:
                self.canvas.create_rectangle(x, y, x + 100, y + 30, fill="#87CEEB", outline="black")
                self.canvas.create_text(x + 50, y + 15, text=current.data, fill="black", font=("Helvetica", 12))
                
                if current.next:
                    self.canvas.create_text(x + 90, y + 15, text="->", fill="black", font=("Helvetica", 12))  # Arrow to next node
                current = current.next
                x += 120  # Move x position for the next node

            # Show null at the end
            self.canvas.create_text(x, y + 15, text="NULL", fill="red", font=("Helvetica", 14))
            self.canvas.create_line(x - 20, y + 15, x, y + 15, arrow=tk.LAST)

if __name__ == "__main__":
    root = tk.Tk()
    app = SinglyLinkedListGUI(root, lambda: root.destroy())  # Example back callback
    root.mainloop()
