import tkinter as tk
from tkinter import messagebox, scrolledtext

class Node:
    def __init__(self, item):
        self.item = item
        self.next = None

class HashTable:
    def __init__(self, size):
        self.size = size
        self.table = [None] * size

    def hash_function(self, value):
        """Calculate the hash index based on the ASCII sum of the characters."""
        ascii_sum = sum(ord(char) for char in value)
        return ascii_sum % self.size

    def add(self, value):
        """Add a value to the hash table using chaining for collision management."""
        index = self.hash_function(value)
        new_node = Node(value)
        if self.table[index] is None:
            self.table[index] = new_node
        else:
            current = self.table[index]
            while current.next is not None:
                current = current.next
            current.next = new_node

    def delete(self, value):
        """Delete a value from the hash table."""
        index = self.hash_function(value)
        current = self.table[index]
        prev = None
        while current is not None:
            if current.item == value:
                if prev is None:
                    self.table[index] = current.next
                else:
                    prev.next = current.next
                return True
            prev = current
            current = current.next
        return False

    def search(self, value):
        """Search for a value in the hash table."""
        index = self.hash_function(value)
        current = self.table[index]
        while current is not None:
            if current.item == value:
                return True
            current = current.next
        return False

    def traverse(self):
        """Traverse the hash table and return items in a readable format."""
        items = []
        for i in range(self.size):
            current = self.table[i]
            while current is not None:
                items.append(current.item)
                current = current.next
        return items

class HashTableGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.hash_table = HashTable(10)  # Hash table size of 10
        self.root.title("Hash Table with Overflow Chaining")
        self.root.configure(bg="#F0F8FF")

        # Set the window size explicitly
        self.root.geometry("1600x1200")  # Set the window size to 1600x1200
        self.root.minsize(1600, 1200)  # Optionally, set a minimum window size
        self.root.maxsize(1600, 1200)  # Optionally, prevent window from being resized beyond this size

        # Headline
        heading_label1 = tk.Label(
            root,
            text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
            font=("Helvetica", 24, "bold"),
            bg="#F0F8FF",
            fg="#0000FF"
        )
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(
            root,
            text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
            font=("Helvetica", 18),
            bg="#F0F8FF",
            fg="#000000"
        )
        heading_label2.pack(pady=(0, 5))
        
        task_label = tk.Label(
            root,
            text="3. Write a program to implement hash table (handling collision)",
            font=("Helvetica", 16),
            bg="#F0F8FF",
            fg="#000000"
        )
        task_label.pack(pady=(0, 20))

        # Create a frame for entry fields
        entry_frame = tk.Frame(root, bg="#F0F8FF")
        entry_frame.pack(pady=10)

        value_label = tk.Label(entry_frame, text="Enter Value:", bg="#F0F8FF", font=("Helvetica", 12))
        value_label.grid(row=0, column=0, padx=5, pady=5)

        self.entry_value = tk.Entry(entry_frame, font=("Helvetica", 16))
        self.entry_value.grid(row=0, column=1, padx=5, pady=5)

        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=10)

        add_button = tk.Button(button_frame, text="Add", command=self.add_item, font=("Helvetica", 16), bg="#87CEEB", fg="black", width=10)
        add_button.grid(row=0, column=0, padx=5)

        delete_button = tk.Button(button_frame, text="Delete", command=self.delete_item, font=("Helvetica", 16), bg="#FF6347", fg="white", width=10)
        delete_button.grid(row=0, column=1, padx=5)

        search_button = tk.Button(button_frame, text="Search", command=self.search_item, font=("Helvetica", 16), bg="#32CD32", fg="white", width=10)
        search_button.grid(row=0, column=2, padx=5)

        back_button = tk.Button(button_frame, text="Back", command=back_callback, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.grid(row=0, column=3, padx=5)

        info_button = tk.Button(button_frame, text="Info", command=self.show_info, font=("Helvetica", 16), bg="#FFD700", fg="black", width=10)
        info_button.grid(row=0, column=4, padx=5)

        self.output = tk.Text(root, width=50, height=10, font=("Helvetica", 12), borderwidth=2, relief="groove")
        self.output.pack(pady=10)

    def add_item(self):
        value = self.entry_value.get()
        if value:
            self.hash_table.add(value)
            index = self.hash_table.hash_function(value)
            ascii_values = [ord(char) for char in value]
            self.output.insert(tk.END, f"Added '{value}' at Index {index} (ASCII: {ascii_values})\n")
            self.entry_value.delete(0, tk.END)
            self.display_table()
        else:
            messagebox.showwarning("Input Error", "Please enter a value.")

    def delete_item(self):
        value = self.entry_value.get()
        if value:
            if self.hash_table.delete(value):
                self.output.insert(tk.END, f"Deleted '{value}' from the hash table.\n")
            else:
                messagebox.showwarning("Not Found", f"'{value}' not found in the hash table.")
            self.entry_value.delete(0, tk.END)
            self.display_table()
        else:
            messagebox.showwarning("Input Error", "Please enter a value.")

    def search_item(self):
        value = self.entry_value.get()
        if value:
            if self.hash_table.search(value):
                index = self.hash_table.hash_function(value)
                ascii_values = [ord(char) for char in value]
                self.output.insert(tk.END, f"Found '{value}' at Index {index} (ASCII: {ascii_values})\n")
            else:
                messagebox.showwarning("Not Found", f"'{value}' not found in the hash table.")
            self.entry_value.delete(0, tk.END)
            self.display_table()
        else:
            messagebox.showwarning("Input Error", "Please enter a value.")

    def display_table(self):
        self.output.insert(tk.END, "Current Hash Table:\n")
        for i, bucket in enumerate(self.hash_table.table):
            current = bucket
            items = []
            while current is not None:
                items.append(current.item)
                current = current.next
            self.output.insert(tk.END, f"Index {i}: {items}\n")

    def show_info(self):
        info_window = tk.Toplevel(self.root)
        info_window.title("Hash Table with Collision Handling")
        info_window.geometry("1600x1200")  # Set the info window size to 1600x1200
        info_window.configure(bg="#F0F8FF")

        info_content = (
            "2. Collision Handling in Hash Tables:\n\n"
            "   When two keys hash to the same index, a collision occurs. This can be handled in several ways:\n"
            "   - Open Addressing: Find a new spot in the table.\n"
            "   - Chaining: Store a list of elements at the same index.\n\n"
            "3. In this program, we use Chaining to handle collisions. Each index of the hash table holds a linked list of nodes.\n"
            "   When two values hash to the same index, the new value is added to the linked list at that index.\n\n"
            "4. Hash Function:\n"
            "   - The hash function in this program computes the index by summing the ASCII values of all characters in the string.\n"
            "   - The index is the result of this sum modulo the size of the hash table.\n\n"
        )

        # ScrolledText for displaying info content
        info_text = scrolledtext.ScrolledText(info_window, font=("Helvetica", 12), bg="#F0F8FF", fg="green", wrap=tk.WORD, height=20)
        info_text.pack(expand=True, fill='both', padx=10, pady=10)

        info_text.insert(tk.END, info_content)
        info_text.config(state=tk.DISABLED)  # Make it read-only

        back_button = tk.Button(info_window, text="Back", command=info_window.destroy, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

# Main application setup
def main():
    root = tk.Tk()
    root.geometry("1600x1200")  # Explicitly set the window size
    root.minsize(1600, 1200)  # Optionally, set a minimum window size
    root.maxsize(1600, 1200)  # Optionally, prevent resizing beyond this size
    app = HashTableGUI(root, root.destroy)  # Pass the back function
    root.mainloop()

if __name__ == "__main__":
    main()
