import tkinter as tk
from tkinter import messagebox, scrolledtext
import heapq  # To use the priority queue functionalities

class PriorityQueue:
    def __init__(self):
        self.elements = []

    def is_empty(self):
        return len(self.elements) == 0

    def enqueue(self, item, priority):
        heapq.heappush(self.elements, (priority, item))

    def dequeue(self):
        if not self.is_empty():
            return heapq.heappop(self.elements)[1]
        return None

    def size(self):
        return len(self.elements)

    def search(self, item):
        for priority, queue_item in self.elements:
            if queue_item == item:
                return True
        return False

    def traverse(self):
        return sorted(self.elements, key=lambda x: x[0])

class PriorityQueueGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.queue = PriorityQueue()
        self.root.title("Priority Queue Implementation")
        self.root.geometry("1600x1200")  # Set window size
        self.root.configure(bg="#F0F8FF")

        # Headline
        heading_label1 = tk.Label(
            root,
            text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
            font=("Helvetica", 24, "bold"),
            bg="#F0F8FF",
            fg="#0000FF"
        )
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(
            root,
            text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
            font=("Helvetica", 18),
            bg="#F0F8FF",
            fg="#000000"
        )
        heading_label2.pack(pady=(0, 5))

        task_label = tk.Label(
            root,
            text="6. Write a program to implement Priority Queue with insertion, deletion, size, search operations using heapq",
            font=("Helvetica", 16),
            bg="#F0F8FF",
            fg="#000000"
        )
        task_label.pack(pady=(0, 20))

        # Create a frame for entry fields and labels
        entry_frame = tk.Frame(root, bg="#F0F8FF")
        entry_frame.pack(pady=10)

        # Labels and Entry fields
        value_label = tk.Label(entry_frame, text="Enter Value:", bg="#F0F8FF", font=("Helvetica", 12))
        value_label.grid(row=0, column=0, padx=5, pady=5)

        self.entry_value = tk.Entry(entry_frame, font=("Helvetica", 16))
        self.entry_value.grid(row=0, column=1, padx=5, pady=5)

        priority_label = tk.Label(entry_frame, text="Enter Priority:", bg="#F0F8FF", font=("Helvetica", 12))
        priority_label.grid(row=1, column=0, padx=5, pady=5)

        self.entry_priority = tk.Entry(entry_frame, font=("Helvetica", 16))
        self.entry_priority.grid(row=1, column=1, padx=5, pady=5)

        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=10)

        enqueue_button = tk.Button(button_frame, text="Enqueue", command=self.enqueue_item, font=("Helvetica", 16), bg="#87CEEB", fg="black", width=10)
        enqueue_button.grid(row=0, column=0, padx=5)

        dequeue_button = tk.Button(button_frame, text="Dequeue", command=self.dequeue_item, font=("Helvetica", 16), bg="#FF6347", fg="white", width=10)
        dequeue_button.grid(row=0, column=1, padx=5)

        size_button = tk.Button(button_frame, text="Size", command=self.display_size, font=("Helvetica", 16), bg="#32CD32", fg="white", width=10)
        size_button.grid(row=0, column=2, padx=5)

        search_button = tk.Button(button_frame, text="Search", command=self.search_item, font=("Helvetica", 16), bg="#FFD700", fg="black", width=10)
        search_button.grid(row=0, column=3, padx=5)

        info_button = tk.Button(button_frame, text="Info", command=self.open_info_window, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        info_button.grid(row=0, column=4, padx=5)

        self.output = tk.Text(root, width=50, height=10, font=("Helvetica", 12), borderwidth=2, relief="groove")
        self.output.pack(pady=10)

        # Reduced canvas size
        self.canvas = tk.Canvas(root, width=500, height=150, bg="#F0F8FF", highlightthickness=0)
        self.canvas.pack(pady=(10, 20))

        # Updated Back Button
        back_button = tk.Button(root, text="Back", command=back_callback, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=15, height=4)
        back_button.pack(pady=20)

    def enqueue_item(self):
        item = self.entry_value.get()
        priority = self.entry_priority.get()
        if item and priority.isdigit():
            self.queue.enqueue(item, int(priority))
            self.entry_value.delete(0, tk.END)
            self.entry_priority.delete(0, tk.END)
            self.display_queue()
            self.update_visual()
        else:
            messagebox.showwarning("Input Error", "Please enter a valid value and priority.")

    def dequeue_item(self):
        item = self.queue.dequeue()
        if item is not None:
            self.display_queue()
            messagebox.showinfo("Dequeued", f"Dequeued: {item}")
            self.update_visual()
        else:
            messagebox.showwarning("Queue Empty", "No items to dequeue.")

    def display_size(self):
        size = self.queue.size()
        self.output.delete(1.0, tk.END)
        self.output.insert(tk.END, f"Size of Priority Queue: {size}\n")
        self.update_visual()

    def search_item(self):
        item = self.entry_value.get()
        if item:
            found = self.queue.search(item)
            if found:
                messagebox.showinfo("Search Result", f"Item '{item}' found in the queue.")
            else:
                messagebox.showwarning("Search Result", f"Item '{item}' not found in the queue.")
        else:
            messagebox.showwarning("Input Error", "Please enter a value to search.")

    def display_queue(self):
        self.output.delete(1.0, tk.END)
        if self.queue.is_empty():
            self.output.insert(tk.END, "Priority Queue is empty.")
        else:
            items = self.queue.traverse()
            self.output.insert(tk.END, "Current Priority Queue: " + ", ".join([f"{item[1]}(Priority: {item[0]})" for item in items]) + "\n")
        self.update_visual()  # Update visual representation

    def open_info_window(self):
        info_window = tk.Toplevel(self.root)
        info_window.title("Priority Queue Information")
        info_window.geometry("1600x1200")
        info_window.configure(bg="#F0F8FF")

        info_content = (
            "Priority Queue Information:\n\n"
            "1. Definition: A priority queue is an abstract data type that operates similarly to a regular queue but with an added feature: each element has a priority associated with it.\n\n"
            "2. Basic Operations:\n"
            "   - Enqueue: Add an item to the queue with an associated priority.\n"
            "   - Dequeue: Remove the item with the highest priority (or lowest number, if using min-heap).\n"
            "   - Size: Returns the number of elements in the queue.\n"
            "   - Search: Check if an item is present in the queue.\n\n"
            "3. Advantages:\n"
            "   - Efficiently manages the processing of tasks with varying importance.\n\n"
            "4. Disadvantages:\n"
            "   - Additional overhead in maintaining priority order during enqueue and dequeue operations.\n\n"
            "5. About heapq:\n"
            "   - The heapq module in Python provides an implementation of the heap queue algorithm, also known as the priority queue algorithm.\n"
            "   - It maintains the elements in a binary heap structure, which allows for efficient insertion and removal of elements based on their priority.\n"
            "   - The smallest element is always at the root of the heap, making it easy to retrieve the highest priority item quickly.\n"
            "   - This implementation is particularly useful in scenarios where you need to manage tasks that have different priority levels."
        )

        # ScrolledText for displaying priority queue information
        info_text = scrolledtext.ScrolledText(info_window, font=("Helvetica", 12), bg="#F0F8FF", fg="green", wrap=tk.WORD, height=25)
        info_text.pack(expand=True, fill='both', padx=10, pady=10)

        info_text.insert(tk.END, info_content)
        info_text.config(state=tk.DISABLED)

        back_button = tk.Button(info_window, text="Back", command=info_window.destroy, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=15, height=2)
        back_button.pack(pady=20)

    def update_visual(self):
        self.canvas.delete("all")  # Clear the canvas
        current = self.queue.elements
        x = 50  # Starting x position
        y = 20  # Y position

        if self.queue.is_empty():
            self.canvas.create_text(250, 75, text="Queue is empty", fill="red", font=("Helvetica", 14))
        else:
            for priority, item in sorted(current):
                self.canvas.create_rectangle(x, y, x + 120, y + 30, fill="#87CEEB", outline="black")
                self.canvas.create_text(x + 60, y + 15, text=f"{item}(Priority: {priority})", fill="black", font=("Helvetica", 12))
                x += 140  # Move x position for the next item

if __name__ == "__main__":
    root = tk.Tk()
    app = PriorityQueueGUI(root, lambda: root.quit())  # Replace with your back function
    root.mainloop()
