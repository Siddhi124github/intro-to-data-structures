import tkinter as tk
from tkinter import messagebox, scrolledtext

class Node:
    def __init__(self, data):
        self.data = data
        self.next = None
        self.prev = None

class DoublyLinkedList:
    def __init__(self):
        self.head = None

    def is_empty(self):
        return self.head is None

    def insert(self, data):
        new_node = Node(data)
        if self.is_empty():
            self.head = new_node
        else:
            new_node.next = self.head
            self.head.prev = new_node
            self.head = new_node

    def delete(self, data):
        current = self.head
        while current is not None:
            if current.data == data:
                if current.prev:
                    current.prev.next = current.next
                if current.next:
                    current.next.prev = current.prev
                if current == self.head:  # If the head is being deleted
                    self.head = current.next
                return True
            current = current.next
        return False

    def traverse(self):
        elements = []
        current = self.head
        while current is not None:
            elements.append(current.data)
            current = current.next
        return elements

    def size(self):
        count = 0
        current = self.head
        while current:
            count += 1
            current = current.next
        return count

    def search(self, data):
        current = self.head
        while current:
            if current.data == data:
                return True
            current = current.next
        return False

class DoublyLinkedListGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.linked_list = DoublyLinkedList()
        self.root.title("Doubly Linked List Implementation")
        self.root.geometry("1600x1200")  # Set window size
        self.root.configure(bg="#F0F8FF")

        # Headline
        heading_label1 = tk.Label(
            root,
            text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
            font=("Helvetica", 24, "bold"),
            bg="#F0F8FF",
            fg="#0000FF"
        )
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(
            root,
            text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
            font=("Helvetica", 18),
            bg="#F0F8FF",
            fg="#000000"
        )
        heading_label2.pack(pady=(0, 5))

        task_label = tk.Label(
            root,
            text="4. Write a program to implement Doubly Linked List with insertion, deletion, search and size operations",
            font=("Helvetica", 16),
            bg="#F0F8FF",
            fg="#000000"
        )
        task_label.pack(pady=(0, 20))

        self.entry = tk.Entry(root, font=("Helvetica", 16))
        self.entry.pack(pady=(10, 10))

        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=10)

        insert_button = tk.Button(button_frame, text="Insert", command=self.insert_item, font=("Helvetica", 16), bg="#87CEEB", fg="black", width=10)
        insert_button.grid(row=0, column=0, padx=5)

        delete_button = tk.Button(button_frame, text="Delete", command=self.delete_item, font=("Helvetica", 16), bg="#FF6347", fg="white", width=10)
        delete_button.grid(row=0, column=1, padx=5)

        size_button = tk.Button(button_frame, text="Size", command=self.display_size, font=("Helvetica", 16), bg="#32CD32", fg="white", width=10)
        size_button.grid(row=0, column=2, padx=5)

        search_button = tk.Button(button_frame, text="Search", command=self.search_item, font=("Helvetica", 16), bg="#FFD700", fg="black", width=10)
        search_button.grid(row=0, column=3, padx=5)

        info_button = tk.Button(button_frame, text="Info", command=self.open_info_window, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        info_button.grid(row=0, column=4, padx=5)

        self.output = tk.Text(root, width=50, height=10, font=("Helvetica", 12), borderwidth=2, relief="groove")
        self.output.pack(pady=10)

        self.canvas = tk.Canvas(root, width=600, height=200, bg="#F0F8FF", highlightthickness=0)
        self.canvas.pack(pady=(10, 20))

        back_button = tk.Button(root, text="Back", command=back_callback, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

    def insert_item(self):
        data = self.entry.get()
        if data:
            self.linked_list.insert(data)
            self.entry.delete(0, tk.END)
            self.display_list()
            self.update_visual()
        else:
            messagebox.showwarning("Input Error", "Please enter a value to insert.")

    def delete_item(self):
        data = self.entry.get()
        if data:
            if self.linked_list.delete(data):
                self.entry.delete(0, tk.END)
                self.display_list()
                messagebox.showinfo("Deleted", f"Deleted: {data}")
                self.update_visual()
            else:
                messagebox.showwarning("Delete Error", f"{data} not found in the list.")
        else:
            messagebox.showwarning("Input Error", "Please enter a value to delete.")

    def display_size(self):
        size = self.linked_list.size()
        self.output.delete(1.0, tk.END)
        self.output.insert(tk.END, f"List size: {size}\n")
        self.update_visual()

    def search_item(self):
        data = self.entry.get()
        if data:
            found = self.linked_list.search(data)
            if found:
                messagebox.showinfo("Search Result", f"Value '{data}' found in the list.")
            else:
                messagebox.showwarning("Search Result", f"Value '{data}' not found in the list.")
        else:
            messagebox.showwarning("Input Error", "Please enter a value to search.")

    def display_list(self):
        self.output.delete(1.0, tk.END)
        if self.linked_list.is_empty():
            self.output.insert(tk.END, "List is empty.")
        else:
            elements = self.linked_list.traverse()
            self.output.insert(tk.END, "Current List: " + " <-> ".join(elements) + "\n")
        self.update_visual()

    def open_info_window(self):
        info_window = tk.Toplevel(self.root)
        info_window.title("Doubly Linked List Information")
        info_window.geometry("1600x1200")
        info_window.configure(bg="#F0F8FF")

        info_content = (
            "Doubly Linked List Information:\n\n"
            "1. Definition: A doubly linked list is a data structure consisting of nodes. Each node contains:\n"
            "- A data field\n"
            "- A reference to the next node (next)\n"
            "- A reference to the previous node (prev)\n\n"
            "2. Basic Operations:\n"
            "- Insert: Adds a new node at the beginning of the list.\n"
            "- Delete: Removes a node from the list.\n"
            "- Search: Finds a specific node in the list.\n"
            "- Size: Returns the number of nodes in the list.\n"
            "3. Advantages:\n"
            "- More flexible than singly linked lists for certain operations.\n"
            "- Can be traversed in both directions.\n"
            "4. Disadvantages:\n"
            "- More memory consumption due to an extra pointer for each node."
        )

        # ScrolledText for displaying linked list information
        info_text = scrolledtext.ScrolledText(info_window, font=("Helvetica", 12), bg="#F0F8FF", fg="green", wrap=tk.WORD, height=25)
        info_text.pack(expand=True, fill='both', padx=10, pady=10)

        info_text.insert(tk.END, info_content)
        info_text.config(state=tk.DISABLED)

        back_button = tk.Button(info_window, text="Back", command=info_window.destroy, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

    def update_visual(self):
        self.canvas.delete("all")  # Clear the canvas
        current = self.linked_list.head
        x = 50  # Starting x position
        y = 100  # Y position

        # Show head pointer
        self.canvas.create_text(30, 30, text="Head", fill="blue", font=("Helvetica", 14))

        if self.linked_list.is_empty():
            self.canvas.create_text(300, 100, text="List is empty", fill="red", font=("Helvetica", 14))
        else:
            while current:
                self.canvas.create_rectangle(x, y, x + 80, y + 30, fill="#87CEEB", outline="black")
                self.canvas.create_text(x + 50, y + 15, text=current.data, fill="black", font=("Helvetica", 12))
                
                if current.next:
                    self.canvas.create_text(x + 100, y + 15, text="<->", fill="black", font=("Helvetica", 12))  # Arrow to next node
                current = current.next
                x += 120  # Move x position for the next node

            # Show null at the end
            self.canvas.create_text(x, y + 15, text="NULL", fill="red", font=("Helvetica", 14))
            self.canvas.create_line(x - 20, y + 15, x, y + 15, arrow=tk.LAST)

if __name__ == "__main__":
    root = tk.Tk()
    app = DoublyLinkedListGUI(root, lambda: root.destroy())
    root.mainloop()
