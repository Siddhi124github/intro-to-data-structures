import tkinter as tk
from tkinter import messagebox, scrolledtext
from collections import Counter
import heapq

class Node:
    def __init__(self, char, freq):
        self.char = char
        self.freq = freq
        self.left = None
        self.right = None

    def __lt__(self, other):
        return self.freq < other.freq

class HuffmanCoding:
    def __init__(self):
        self.codes = {}
        self.reverse_mapping = {}
        self.root = None

    def build_tree(self, text):
        frequency = Counter(text)
        priority_queue = [Node(char, freq) for char, freq in frequency.items()]
        heapq.heapify(priority_queue)

        while len(priority_queue) > 1:
            left = heapq.heappop(priority_queue)
            right = heapq.heappop(priority_queue)
            merged = Node(None, left.freq + right.freq)
            merged.left = left
            merged.right = right
            heapq.heappush(priority_queue, merged)

        self.root = heapq.heappop(priority_queue)
        self.make_codes(self.root)

    def make_codes(self, node, current_code=""):
        if node is None:
            return
        if node.char is not None:
            self.codes[node.char] = current_code
            self.reverse_mapping[current_code] = node.char
            return
        self.make_codes(node.left, current_code + "0")
        self.make_codes(node.right, current_code + "1")

    def encode(self, text):
        self.build_tree(text)
        return "".join(self.codes[char] for char in text), self.codes

    def decode(self, encoded_text):
        current_code = ""
        decoded_output = []
        for bit in encoded_text:
            current_code += bit
            if current_code in self.reverse_mapping:
                decoded_output.append(self.reverse_mapping[current_code])
                current_code = ""
        return "".join(decoded_output)

class HuffmanCodingGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.huffman = HuffmanCoding()
        self.root.title("Huffman Coding Implementation")
        self.root.geometry("1600x1200")
        self.root.configure(bg="#F0F8FF")

        # Headline
        heading_label1 = tk.Label(root, text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
                                   font=("Helvetica", 24, "bold"), bg="#F0F8FF", fg="#0000FF")
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(root, text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
                                   font=("Helvetica", 18), bg="#F0F8FF", fg="#000000")
        heading_label2.pack(pady=(0, 5))

        task_label = tk.Label(root, text="8. Implement Huffman Coding",
                               font=("Helvetica", 16), bg="#F0F8FF", fg="#000000")
        task_label.pack(pady=(0, 20))

        # Create a frame for entry fields and labels
        entry_frame = tk.Frame(root, bg="#F0F8FF")
        entry_frame.pack(pady=10)

        # Labels and Entry fields
        input_label = tk.Label(entry_frame, text="Enter Text:", bg="#F0F8FF", font=("Helvetica", 12))
        input_label.grid(row=0, column=0, padx=5, pady=5)

        self.entry_text = tk.Entry(entry_frame, width=50, font=("Helvetica", 16))
        self.entry_text.grid(row=0, column=1, padx=5, pady=5)

        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=10)

        encode_button = tk.Button(button_frame, text="Encode", command=self.encode_text,
                                   font=("Helvetica", 16), bg="#87CEEB", fg="black", width=10)
        encode_button.grid(row=0, column=0, padx=5)

        decode_button = tk.Button(button_frame, text="Decode", command=self.decode_text,
                                   font=("Helvetica", 16), bg="#FF6347", fg="white", width=10)
        decode_button.grid(row=0, column=1, padx=5)

        display_tree_button = tk.Button(button_frame, text="Display Tree", command=self.open_tree_window,
                                         font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        display_tree_button.grid(row=0, column=2, padx=5)

        info_button = tk.Button(root, text="Info", command=self.open_info_window,
                                font=("Helvetica", 16), bg="#FFD700", fg="black", width=10)
        info_button.pack(pady=10)

        self.output = tk.Text(root, width=80, height=15, font=("Helvetica", 12), borderwidth=2, relief="groove")
        self.output.pack(pady=10)

        back_button = tk.Button(root, text="Back", command=back_callback,
                                font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

    def encode_text(self):
        text = self.entry_text.get()
        if text:
            encoded_text, codes = self.huffman.encode(text)
            self.output.delete(1.0, tk.END)
            self.output.insert(tk.END, "Character Frequencies and Codes:\n")
            for char, code in codes.items():
                freq = text.count(char)
                self.output.insert(tk.END, f"'{char}': Frequency = {freq}, Code = {code}\n")
            self.output.insert(tk.END, "\nEncoded Text: " + encoded_text + "\n")
            self.output.insert(tk.END, "Encoded Length: " + str(len(encoded_text)) + " bits\n")
        else:
            messagebox.showwarning("Input Error", "Please enter some text.")

    def decode_text(self):
        lines = self.output.get(1.0, tk.END).strip().split("\n")
        encoded_text_line = next((line for line in lines if line.startswith("Encoded Text:")), None)
        
        if encoded_text_line:
            encoded_text = encoded_text_line.replace("Encoded Text: ", "").strip()
            if encoded_text:
                decoded_text = self.huffman.decode(encoded_text)
                self.output.insert(tk.END, "Decoded Text: " + decoded_text + "\n")
            else:
                messagebox.showwarning("Input Error", "No encoded text found.")
        else:
            messagebox.showwarning("Input Error", "Please encode text first.")

    def open_tree_window(self):
        tree_window = tk.Toplevel(self.root)
        tree_window.title("Huffman Tree Display")
        tree_window.geometry("800x600")
        tree_window.configure(bg="#F0F8FF")

        canvas = tk.Canvas(tree_window, width=800, height=600, bg="#F0F8F8")
        canvas.pack(pady=20)

        self.draw_tree(canvas)

    def draw_tree(self, canvas):
        canvas.delete("all")  # Clear the canvas
        self._draw_node(self.huffman.root, 400, 30, 200, canvas)

    def _draw_node(self, node, x, y, offset, canvas):
        if node:
            if node.char is not None:
                canvas.create_oval(x - 20, y - 20, x + 20, y + 20, fill="lightblue")
                canvas.create_text(x, y, text=f"{node.char}\n({node.freq})", font=("Helvetica", 12, "bold"))
            else:
                canvas.create_oval(x - 20, y - 20, x + 20, y + 20, fill="lightgray")
                canvas.create_text(x, y, text=f"Total: {node.freq}", font=("Helvetica", 12, "bold"))

            if node.left:
                canvas.create_line(x, y + 20, x - offset, y + 70)
                self._draw_node(node.left, x - offset, y + 70, offset // 2, canvas)
            if node.right:
                canvas.create_line(x, y + 20, x + offset, y + 70)
                self._draw_node(node.right, x + offset, y + 70, offset // 2, canvas)

    def open_info_window(self):
        info_window = tk.Toplevel(self.root)
        info_window.title("Huffman Coding Information")
        info_window.geometry("1600x1200")
        info_window.configure(bg="#F0F8FF")

        info_content = (
            "Huffman Coding Information:\n\n"
            "1. Definition:\n"
            "   Huffman coding is a lossless data compression algorithm that assigns variable-length codes "
            "to input characters based on their frequencies.\n\n"
            "2. How it Works:\n"
            "   - It builds a binary tree where each leaf node represents a character.\n"
            "   - Characters with higher frequencies are closer to the root, resulting in shorter codes.\n\n"
            "3. Steps:\n"
            "   - Calculate frequency of each character in the input text.\n"
            "   - Create leaf nodes for each character.\n"
            "   - Merge nodes based on frequency to form the Huffman tree.\n"
            "   - Generate codes by traversing the tree.\n\n"
            "4. Benefits:\n"
            "   - Efficient compression and reduced average code length.\n\n"
            "5. Applications:\n"
            "   - Used in data compression formats like ZIP and JPEG."
        )

        # ScrolledText for displaying Huffman coding information
        info_text = scrolledtext.ScrolledText(info_window, font=("Helvetica", 12), bg="#F0F8FF", fg="green", wrap=tk.WORD, height=25)
        info_text.pack(expand=True, fill='both', padx=10, pady=10)

        info_text.insert(tk.END, info_content)
        info_text.config(state=tk.DISABLED)

        # Back Button
        back_button = tk.Button(info_window, text="Back", command=info_window.destroy,
                                font=("Helvetica", 16), bg="#B0E0E6", fg="black")
        back_button.pack(pady=10)

# Example usage of the GUI
def main():
    root = tk.Tk()
    app = HuffmanCodingGUI(root, lambda: root.destroy())
    root.mainloop()

if __name__ == "__main__":
    main()
