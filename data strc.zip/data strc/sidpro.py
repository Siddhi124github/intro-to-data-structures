import tkinter as tk
from tkinter import messagebox
from adt_queue import QueueGUI
from stack import StackGUI
from singly_linked_list import SinglyLinkedListGUI
from doubly_linked_list import DoublyLinkedListGUI
from priority_queue import PriorityQueueGUI
from priority_queue_linked_list import PriorityQueueGUI as PriorityQueueWithoutHeapqGUI
from binarytree import BinaryTreeGUI
from huffman import HuffmanCodingGUI
from dfsandbfs import GraphGUI
from tsp import TSPGUI
from handlingcollison import HashTableGUI as HashTableWithCollisionGUI
from nocollison import HashTableGUI as HashTableWithoutCollisionGUI

class MainApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Data Structure Operations")
        self.root.geometry("1600x1200")
        self.root.configure(bg="#F0F8FF")

        # Headline
        heading_label1 = tk.Label(
            root,
            text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
            font=("Helvetica", 24, "bold"),
            bg="#F0F8FF",
            fg="#0000FF"
        )
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(
            root,
            text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
            font=("Helvetica", 18),
            bg="#F0F8FF",
            fg="#000000"
        )
        heading_label2.pack(pady=(0, 10))

        # Academic Year
        academic_year_label = tk.Label(
            root,
            text="Academic Year: 2024-2025",
            font=("Helvetica", 16),
            bg="#F0F8FF",
            fg="#000000"
        )
        academic_year_label.pack(pady=(0, 10))

        # Index Heading
        index_label = tk.Label(
            root,
            text="Index",
            font=("Helvetica", 20, "bold"),
            bg="#F0F8FF",
            fg="#0000FF"
        )
        index_label.pack(pady=(0, 10))

        # Button Frame
        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=20)

        # Create buttons
        button_names = [
            ("1. ADT Queue", self.open_queue_gui),
            ("2. Stack", self.open_stack_gui),
            ("3. Singly Linked List", self.open_linked_list_gui),
            ("4. Doubly Linked List", self.open_doubly_linked_list_gui),
            ("5. Priority Queue", self.open_priority_queue_gui),
            ("6. Priority Queue without heapq", self.open_priority_queue_without_heapq_gui),
            ("7. Binary Tree", self.open_binary_tree_gui),
            ("8. Huffman Coding", self.open_huffman_gui),
            ("9. DFS and BFS", self.open_dfs_bfs_gui),
            ("10. Traveling Salesman Problem", self.open_tsp_gui),
            ("11. Hash Table with Collision Handling", self.open_hash_table_with_collision_gui),
            ("12. Hash Table without Collision Handling", self.open_hash_table_without_collision_gui)
        ]

        # Place buttons in a vertical column
        for index, (name, command) in enumerate(button_names):
            button = tk.Button(
                button_frame,
                text=name,
                command=command,
                font=("Helvetica", 16),
                bg="#87CEEB",
                fg="black",
                width=32,
                height=2
            )
            button.grid(row=index // 2, column=index % 2, padx=10, pady=10)

    def open_queue_gui(self):
        self.root.withdraw()
        queue_window = tk.Toplevel(self.root)
        QueueGUI(queue_window, self.show_main)

    def open_stack_gui(self):
        self.root.withdraw()
        stack_window = tk.Toplevel(self.root)
        StackGUI(stack_window, self.show_main)

    def open_linked_list_gui(self):
        self.root.withdraw()
        linked_list_window = tk.Toplevel(self.root)
        SinglyLinkedListGUI(linked_list_window, self.show_main)

    def open_doubly_linked_list_gui(self):
        self.root.withdraw()
        doubly_linked_list_window = tk.Toplevel(self.root)
        DoublyLinkedListGUI(doubly_linked_list_window, self.show_main)

    def open_priority_queue_gui(self):
        self.root.withdraw()
        priority_queue_window = tk.Toplevel(self.root)
        PriorityQueueGUI(priority_queue_window, self.show_main)

    def open_priority_queue_without_heapq_gui(self):
        self.root.withdraw()
        priority_queue_window = tk.Toplevel(self.root)
        PriorityQueueWithoutHeapqGUI(priority_queue_window, self.show_main)

    def open_binary_tree_gui(self):
        self.root.withdraw()
        binary_tree_window = tk.Toplevel(self.root)
        BinaryTreeGUI(binary_tree_window, self.show_main)

    def open_huffman_gui(self):
        self.root.withdraw()
        huffman_window = tk.Toplevel(self.root)
        HuffmanCodingGUI(huffman_window, self.show_main)

    def open_dfs_bfs_gui(self):
        self.root.withdraw()
        dfs_bfs_window = tk.Toplevel(self.root)
        GraphGUI(dfs_bfs_window, self.show_main)

    def open_tsp_gui(self):
        self.root.withdraw()
        tsp_window = tk.Toplevel(self.root)
        TSPGUI(tsp_window, self.show_main)

    def open_hash_table_with_collision_gui(self):
        self.root.withdraw()
        hash_table_window = tk.Toplevel(self.root)
        HashTableWithCollisionGUI(hash_table_window, self.show_main)  # Open the Hash Table with collision GUI

    def open_hash_table_without_collision_gui(self):
        self.root.withdraw()
        hash_table_window = tk.Toplevel(self.root)
        HashTableWithoutCollisionGUI(hash_table_window, self.show_main)  # Open the Hash Table without collision GUI

    def show_main(self):
        self.root.deiconify()  # Show the main window again

if __name__ == "__main__":
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()
