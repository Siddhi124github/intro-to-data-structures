import tkinter as tk
from tkinter import messagebox, scrolledtext

class Queue:
    def __init__(self):
        self.items = []
    
    def is_empty(self):
        return len(self.items) == 0
    
    def enqueue(self, item):
        self.items.append(item)
    
    def dequeue(self):
        if not self.is_empty():
            return self.items.pop(0)
        else:
            return None
    
    def peek(self):
        if not self.is_empty():
            return self.items[0]
        else:
            return None
    
    def size(self):
        return len(self.items)

class QueueGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.queue = Queue()
        self.root.title("Queue Implementation")
        self.root.geometry("1600x1200")
        self.root.configure(bg="#F0F8FF")

        # Headline
        heading_label1 = tk.Label(
            root,
            text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
            font=("Helvetica", 24, "bold"),
            bg="#F0F8FF",
            fg="#0000FF"
        )
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(
            root,
            text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
            font=("Helvetica", 18),
            bg="#F0F8FF",
            fg="#000000"
        )
        heading_label2.pack(pady=(0, 5))

        task_label = tk.Label(
            root,
            text="1. Write a program to implement Abstract Data Types (ADT)",
            font=("Helvetica", 16),
            bg="#F0F8FF",
            fg="#000000"
        )
        task_label.pack(pady=(0, 20))

        self.entry = tk.Entry(root, font=("Helvetica", 16))
        self.entry.pack(pady=(10, 10))

        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=10)

        enqueue_button = tk.Button(button_frame, text="Enqueue", command=self.enqueue_item, font=("Helvetica", 16), bg="#87CEEB", fg="black", width=10)
        enqueue_button.grid(row=0, column=0, padx=5)

        dequeue_button = tk.Button(button_frame, text="Dequeue", command=self.dequeue_item, font=("Helvetica", 16), bg="#FF6347", fg="white", width=10)
        dequeue_button.grid(row=0, column=1, padx=5)

        peek_button = tk.Button(button_frame, text="Peek", command=self.peek_item, font=("Helvetica", 16), bg="#32CD32", fg="white", width=10)
        peek_button.grid(row=0, column=2, padx=5)

        size_button = tk.Button(button_frame, text="Size", command=self.show_size, font=("Helvetica", 16), bg="#FFD700", fg="black", width=10)
        size_button.grid(row=0, column=3, padx=5)

        info_button = tk.Button(button_frame, text="Info", command=self.open_info_window, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        info_button.grid(row=0, column=4, padx=5)

        # Frame for output
        self.output_frame = tk.Frame(root, bg="#F0F8FF", relief="groove", borderwidth=2)
        self.output_frame.pack(pady=10, padx=20)

        self.output_label = tk.Label(self.output_frame, text="", font=("Helvetica", 12), bg="#F0F8FF", fg="green", justify="left", anchor="nw", width=50, height=10, wraplength=750)
        self.output_label.pack(padx=10, pady=10)

        self.canvas = tk.Canvas(root, width=400, height=150, bg="#F0F8FF", highlightthickness=0)
        self.canvas.pack(pady=(10, 20))

        back_button = tk.Button(root, text="Back", command=back_callback, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

    def enqueue_item(self):
        item = self.entry.get()
        if item:
            self.queue.enqueue(item)
            self.entry.delete(0, tk.END)
            self.display_queue()
            self.update_visual()  # Update the visual representation
        else:
            messagebox.showwarning("Input Error", "Please enter a value to enqueue.")

    def dequeue_item(self):
        item = self.queue.dequeue()
        if item is not None:
            self.display_queue()
            messagebox.showinfo("Dequeued", f"Dequeued: {item}")
            self.update_visual()  # Update the visual representation
        else:
            messagebox.showwarning("Queue Empty", "No items to dequeue.")

    def peek_item(self):
        item = self.queue.peek()
        if item is not None:
            messagebox.showinfo("Peek", f"Front item: {item}")
        else:
            messagebox.showwarning("Queue Empty", "No items in the queue.")

    def show_size(self):
        size = self.queue.size()
        messagebox.showinfo("Size", f"Queue size: {size}")

    def display_queue(self):
        if self.queue.is_empty():
            self.output_label.config(text="Queue is empty.")
        else:
            items = "\n".join(self.queue.items)
            self.output_label.config(text=f"Current Queue:\n{items}")

    def open_info_window(self):
        info_window = tk.Toplevel(self.root)
        info_window.title("Queue Information")
        info_window.geometry("1600x1200")
        info_window.configure(bg="#F0F8FF")

        info_content = (
            "Queue Information:\n\n"
            "1. Definition: A Queue is a linear data structure that follows the First In First Out (FIFO) principle.\n"
            "2. Basic Operations:\n"
            "   - Enqueue: Add an item to the end of the queue.\n"
            "   - Dequeue: Remove the item from the front of the queue.\n"
            "   - Peek: Get the front item without removing it.\n"
            "   - Size: Get the number of items in the queue.\n"
            "3. Advantages:\n"
            "   - Efficient for processing tasks in the order they arrive.\n"
            "   - Useful for scheduling processes in operating systems.\n"
            "4. Disadvantages:\n"
            "   - Fixed size (if implemented with arrays), which can lead to overflow.\n"
            "   - Can be less efficient in terms of memory when resizing is needed."
        )

        # ScrolledText for displaying queue information
        info_text = scrolledtext.ScrolledText(info_window, font=("Helvetica", 12), bg="#F0F8FF", fg="green", wrap=tk.WORD, height=25)
        info_text.pack(expand=True, fill='both', padx=10, pady=10)

        info_text.insert(tk.END, info_content)
        info_text.config(state=tk.DISABLED)  # Make it read-only

        back_button = tk.Button(info_window, text="Back", command=info_window.destroy, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

    def update_visual(self):
        self.canvas.delete("all")  # Clear the canvas
        queue_length = self.queue.size()
        if queue_length == 0:
            self.canvas.create_text(200, 75, text="Queue is empty", fill="red", font=("Helvetica", 14))
        else:
            # Draw the queue representation
            for i, item in enumerate(self.queue.items):
                x = 50 + i * 80  # Position each item
                self.canvas.create_rectangle(x, 50, x + 60, 100, fill="#87CEEB", outline="black")
                self.canvas.create_text(x + 30, 75, text=item, fill="black", font=("Helvetica", 12))

            # Indicate front and rear
            self.canvas.create_line(50, 50, 50, 100, fill="green", dash=(4, 2))  # Front indicator
            self.canvas.create_line(50 + (queue_length - 1) * 80, 50, 50 + (queue_length - 1) * 80, 100, fill="red", dash=(4, 2))  # Rear indicator

if __name__ == "__main__":
    root = tk.Tk()
    app = QueueGUI(root, lambda: root.destroy())  # Example back callback
    root.mainloop()
