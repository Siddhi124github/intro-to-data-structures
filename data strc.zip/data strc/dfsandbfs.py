import tkinter as tk
from tkinter import simpledialog, messagebox, scrolledtext
import networkx as nx
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

class Graph:
    def __init__(self):
        self.graph = nx.Graph()

    def add_vertices(self, vertices):
        for vertex in vertices:
            self.graph.add_node(vertex.strip())

    def add_edge(self, u, v):
        self.graph.add_edge(u, v)

    def remove_vertex(self, vertex):
        self.graph.remove_node(vertex)

    def remove_edge(self, u, v):
        self.graph.remove_edge(u, v)

    def draw_graph(self, bfs_edges=None, dfs_edges=None):
        plt.clf()  # Clear the current figure

        # Default colors
        node_color = 'lightblue'
        edge_color = ['black'] * len(self.graph.edges())

        # Convert edges to sets for easy lookup
        bfs_edges_set = set(bfs_edges) if bfs_edges else set()
        dfs_edges_set = set(dfs_edges) if dfs_edges else set()

        # Highlight BFS edges in red and DFS edges in green
        for i, edge in enumerate(self.graph.edges()):
            if edge in bfs_edges_set:
                edge_color[i] = 'red'
            elif edge in dfs_edges_set:
                edge_color[i] = 'green'

        # Draw the graph with the updated edge colors
        nx.draw(self.graph, with_labels=True, node_color=node_color, 
                node_size=2000, font_size=16, font_color='black', 
                edge_color=edge_color)
        plt.title("Graph Visualization")
        plt.show()

    def bfs(self, start_vertex):
        return list(nx.bfs_edges(self.graph, start_vertex))

    def dfs(self, start_vertex):
        return list(nx.dfs_edges(self.graph, start_vertex))

class GraphGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.graph = Graph()
        self.root.title("Graph Implementation")
        self.root.geometry("1600x1200")  # Make the window fullscreen
        self.root.configure(bg="#F0F8FF")

        # Headline
        heading_label1 = tk.Label(root, text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
                                   font=("Helvetica", 24, "bold"), bg="#F0F8FF", fg="#0000FF")
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(root, text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
                                   font=("Helvetica", 18), bg="#F0F8FF", fg="#000000")
        heading_label2.pack(pady=(0, 5))

        task_label = tk.Label(root, text="Graph Implementation: Create, Insert, Delete Vertices",
                               font=("Helvetica", 16), bg="#F0F8FF", fg="#000000")
        task_label.pack(pady=(0, 20))

        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=10)

        # Create buttons
        button_font = ("Helvetica", 16)
        button_bg = "#87CEEB"
        button_fg = "black"

        add_vertices_button = tk.Button(button_frame, text="Add Vertices", 
                                         command=self.add_vertices, font=button_font, 
                                         bg=button_bg, fg=button_fg, width=15)
        add_vertices_button.grid(row=0, column=0, padx=10, pady=10)

        num_edges_button = tk.Button(button_frame, text="Input Edges", 
                                      command=self.input_edges, font=button_font, 
                                      bg=button_bg, fg=button_fg, width=15)
        num_edges_button.grid(row=0, column=1, padx=10, pady=10)

        remove_vertex_button = tk.Button(button_frame, text="Remove Vertex", 
                                          command=self.remove_vertex, font=button_font, 
                                          bg="#FF6347", fg="white", width=15)
        remove_vertex_button.grid(row=1, column=0, padx=10, pady=10)

        remove_edge_button = tk.Button(button_frame, text="Remove Edge", 
                                        command=self.remove_edge, font=button_font, 
                                        bg="#FF6347", fg="white", width=15)
        remove_edge_button.grid(row=1, column=1, padx=10, pady=10)

        display_graph_button = tk.Button(button_frame, text="Display Graph", 
                                          command=self.display_graph, font=button_font, 
                                          bg="#32CD32", fg="white", width=15)
        display_graph_button.grid(row=2, column=0, padx=10, pady=10)

        bfs_button = tk.Button(button_frame, text="BFS Traversal", 
                               command=self.perform_bfs, font=button_font, 
                               bg="#FFD700", fg="black", width=15)
        bfs_button.grid(row=2, column=1, padx=10, pady=10)

        dfs_button = tk.Button(button_frame, text="DFS Traversal", 
                               command=self.perform_dfs, font=button_font, 
                               bg="#FFD700", fg="black", width=15)
        dfs_button.grid(row=3, column=0, padx=10, pady=10)

        info_button = tk.Button(button_frame, text="Info", 
                                command=self.open_info_window, font=button_font, 
                                bg="#FFD700", fg="black", width=15)
        info_button.grid(row=3, column=1, padx=10, pady=10)

        back_button = tk.Button(root, text="Back", command=back_callback, 
                                font=button_font, bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=(20, 10))

    def add_vertices(self):
        vertices = simpledialog.askstring("Input", "Enter vertex names separated by commas:")
        if vertices:
            vertex_list = vertices.split(',')
            self.graph.add_vertices(vertex_list)
            messagebox.showinfo("Success", f"Vertices '{vertices}' added.")

    def input_edges(self):
        num_edges = simpledialog.askinteger("Input", "Enter the number of edges:")
        if num_edges is not None:
            self.show_edge_input_window(num_edges)

    def show_edge_input_window(self, num_edges):
        edge_window = tk.Toplevel(self.root)
        edge_window.title("Input Edges")
        edge_window.configure(bg="#F0F8FF")

        tk.Label(edge_window, text="Enter edges in (u,v) format:", 
                 font=("Helvetica", 14), bg="#F0F8FF").pack(pady=10)

        edge_entries = []
        for i in range(num_edges):
            entry = tk.Entry(edge_window, width=20, font=("Helvetica", 14))
            entry.pack(pady=5)
            edge_entries.append(entry)

        def add_edges():
            for entry in edge_entries:
                edge = entry.get()
                if edge:
                    try:
                        u, v = edge.split(',')
                        self.graph.add_edge(u.strip(), v.strip())
                    except ValueError:
                        messagebox.showerror("Error", f"Invalid edge format: {edge}")
                        return
            messagebox.showinfo("Success", f"Edges added successfully!")
            edge_window.destroy()

        tk.Button(edge_window, text="Add Edges", command=add_edges, 
                  font=("Helvetica", 14), bg="#87CEEB").pack(pady=20)

    def remove_vertex(self):
        vertex = simpledialog.askstring("Input", "Enter vertex name to remove:")
        if vertex:
            self.graph.remove_vertex(vertex)
            messagebox.showinfo("Success", f"Vertex '{vertex}' removed.")

    def remove_edge(self):
        edge = simpledialog.askstring("Input", "Enter edge to remove (u,v):")
        if edge:
            try:
                u, v = edge.split(',')
                self.graph.remove_edge(u.strip(), v.strip())
                messagebox.showinfo("Success", f"Edge '{u.strip()} - {v.strip()}' removed.")
            except ValueError:
                messagebox.showerror("Error", "Invalid edge format.")

    def display_graph(self):
        if not self.graph.graph.nodes:
            messagebox.showwarning("Empty Graph", "No vertices to display.")
        else:
            self.graph.draw_graph()

    def perform_bfs(self):
        start_vertex = simpledialog.askstring("BFS Traversal", "Enter the starting vertex:")
        if start_vertex and start_vertex in self.graph.graph.nodes:
            bfs_edges = self.graph.bfs(start_vertex)
            self.graph.draw_graph(bfs_edges=bfs_edges)
            bfs_order = " -> ".join([f"{u}-{v}" for u, v in bfs_edges])
            messagebox.showinfo("BFS Traversal", f"BFS edges: {bfs_order}")
        else:
            messagebox.showerror("Error", "Invalid starting vertex.")

    def perform_dfs(self):
        start_vertex = simpledialog.askstring("DFS Traversal", "Enter the starting vertex:")
        if start_vertex and start_vertex in self.graph.graph.nodes:
            dfs_edges = self.graph.dfs(start_vertex)
            self.graph.draw_graph(dfs_edges=dfs_edges)
            dfs_order = " -> ".join([f"{u}-{v}" for u, v in dfs_edges])
            messagebox.showinfo("DFS Traversal", f"DFS edges: {dfs_order}")
        else:
            messagebox.showerror("Error", "Invalid starting vertex.")

    def open_info_window(self):
        # Create a new top-level window for Graph Information
        info_window = tk.Toplevel(self.root)
        info_window.title("Graph Implementation Information")
        info_window.geometry("1600x1200")  # Set the window size to 1600x1200
        info_window.configure(bg="#F0F8FF")  # Set background color

        # Information content for Graph Implementation
        info_content = (
            "Graph Implementation Information:\n\n"
            "1. Definition:\n"
            "   A graph is a collection of nodes (vertices) and edges (connections between nodes).\n"
            "   In this program, we allow the creation of undirected graphs where nodes are connected by edges.\n\n"
            
            "2. Operations Supported:\n"
            "   - Add Vertices: Add new nodes to the graph.\n"
            "   - Remove Vertices: Remove existing nodes and their associated edges.\n"
            "   - Add Edges: Connect two nodes by adding an edge between them.\n"
            "   - Remove Edges: Remove the edge between two nodes.\n\n"
            
            "3. Traversal Methods:\n"
            "   - BFS (Breadth-First Search): Traverse the graph starting from a specific node and visiting all its neighbors first.\n"
            "   - DFS (Depth-First Search): Traverse the graph by exploring as far as possible along each branch before backtracking.\n\n"
            
            "4. Graph Visualization:\n"
            "   - The graph is displayed visually with nodes and edges. You can see the results of BFS and DFS traversals by highlighting the edges traversed.\n"
            "   - BFS edges are highlighted in red, and DFS edges are highlighted in green.\n\n"
            
            "5. Applications:\n"
            "   - Graph algorithms like BFS and DFS are fundamental for tasks such as shortest path calculations, network flow, and more.\n"
            "   - This implementation allows you to interact with a graph, add/remove elements, and perform fundamental graph operations."
        )

        # ScrolledText widget for displaying the information
        info_text = scrolledtext.ScrolledText(info_window, font=("Helvetica", 12), bg="#F0F8FF", fg="green", wrap=tk.WORD, height=25)
        info_text.pack(expand=True, fill='both', padx=10, pady=10)

        # Insert the information into the text widget and disable editing
        info_text.insert(tk.END, info_content)
        info_text.config(state=tk.DISABLED)

        # Button to close the information window
        close_button = tk.Button(info_window, text="Close", command=info_window.destroy,
                                 font=("Helvetica", 16), bg="#87CEEB", fg="black")
        close_button.pack(pady=10)

        # Set the minimum size of the window so that the content doesn't overflow
        info_window.minsize(1600, 1200)
