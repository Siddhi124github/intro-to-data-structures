import tkinter as tk
from tkinter import messagebox, scrolledtext

class Stack:
    def __init__(self):
        self.items = []

    def is_empty(self):
        return len(self.items) == 0

    def push(self, item):
        self.items.append(item)

    def pop(self):
        if not self.is_empty():
            return self.items.pop()
        else:
            return None

    def peek(self):
        if not self.is_empty():
            return self.items[-1]
        else:
            return None

    def size(self):
        return len(self.items)

class StackGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.stack = Stack()
        self.root.title("Stack Implementation")
        self.root.geometry("1600x1200")  # Set window size
        self.root.configure(bg="#F0F8FF")

        # Headline
        heading_label1 = tk.Label(
            root,
            text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
            font=("Helvetica", 24, "bold"),
            bg="#F0F8FF",
            fg="#0000FF"
        )
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(
            root,
            text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
            font=("Helvetica", 18),
            bg="#F0F8FF",
            fg="#000000"
        )
        heading_label2.pack(pady=(0, 5))

        task_label = tk.Label(
            root,
            text="2. Write a program to implement Stack with insertion, deletion, traversal operations",
            font=("Helvetica", 16),
            bg="#F0F8FF",
            fg="#000000"
        )
        task_label.pack(pady=(0, 20))

        self.entry = tk.Entry(root, font=("Helvetica", 16))
        self.entry.pack(pady=(10, 10))

        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=10)

        push_button = tk.Button(button_frame, text="Push", command=self.push_item, font=("Helvetica", 16), bg="#87CEEB", fg="black", width=10)
        push_button.grid(row=0, column=0, padx=5)

        pop_button = tk.Button(button_frame, text="Pop", command=self.pop_item, font=("Helvetica", 16), bg="#FF6347", fg="white", width=10)
        pop_button.grid(row=0, column=1, padx=5)

        peek_button = tk.Button(button_frame, text="Peek", command=self.peek_item, font=("Helvetica", 16), bg="#32CD32", fg="white", width=10)
        peek_button.grid(row=0, column=2, padx=5)

        size_button = tk.Button(button_frame, text="Size", command=self.show_size, font=("Helvetica", 16), bg="#FFD700", fg="black", width=10)
        size_button.grid(row=0, column=3, padx=5)

        info_button = tk.Button(button_frame, text="Info", command=self.open_info_window, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        info_button.grid(row=0, column=4, padx=5)

        self.output = tk.Text(root, width=50, height=10, font=("Helvetica", 12), borderwidth=2, relief="groove")
        self.output.pack(pady=10)

        back_button = tk.Button(root, text="Back", command=back_callback, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

        self.canvas = tk.Canvas(root, width=400, height=300, bg="#F0F8FF", highlightthickness=0)
        self.canvas.pack(pady=(10, 20))

    def push_item(self):
        item = self.entry.get()
        if item:
            self.stack.push(item)
            self.entry.delete(0, tk.END)
            self.display_stack()
            self.update_visual()  # Update the visual representation
        else:
            messagebox.showwarning("Input Error", "Please enter a value to push.")

    def pop_item(self):
        item = self.stack.pop()
        if item is not None:
            self.display_stack()
            messagebox.showinfo("Popped", f"Popped: {item}")
            self.update_visual()  # Update the visual representation
        else:
            messagebox.showwarning("Stack Empty", "No items to pop.")

    def peek_item(self):
        item = self.stack.peek()
        if item is not None:
            messagebox.showinfo("Peek", f"Top item: {item}")
        else:
            messagebox.showwarning("Stack Empty", "No items in the stack.")

    def show_size(self):
        size = self.stack.size()
        messagebox.showinfo("Size", f"Stack size: {size}")

    def display_stack(self):
        self.output.delete(1.0, tk.END)
        if self.stack.is_empty():
            self.output.insert(tk.END, "Stack is empty.")
        else:
            self.output.insert(tk.END, "Current Stack:\n")
            for item in reversed(self.stack.items):
                self.output.insert(tk.END, f"{item}\n")

    def open_info_window(self):
        info_window = tk.Toplevel(self.root)
        info_window.title("Stack Information")
        info_window.geometry("1600x1200")
        info_window.configure(bg="#F0F8FF")

        info_content = (
            "Stack Information:\n\n"
            "1. Definition: A Stack is a linear data structure that follows the Last In First Out (LIFO) principle.\n"
            "2. Basic Operations:\n"
            "   - Push: Add an item to the top of the stack.\n"
            "   - Pop: Remove the item from the top of the stack.\n"
            "   - Peek: Get the top item without removing it.\n"
            "   - Size: Get the number of items in the stack.\n"
            "3. Advantages:\n"
            "   - Efficient for managing data in a last-in-first-out manner.\n"
            "   - Useful for backtracking algorithms and expression evaluations.\n"
            "4. Disadvantages:\n"
            "   - Limited access (only to the top item).\n"
            "   - Can overflow if a fixed-size array is used."
        )

        # ScrolledText for displaying stack information
        info_text = scrolledtext.ScrolledText(info_window, font=("Helvetica", 12), bg="#F0F8FF", fg="green", wrap=tk.WORD, height=25)
        info_text.pack(expand=True, fill='both', padx=10, pady=10)

        info_text.insert(tk.END, info_content)
        info_text.config(state=tk.DISABLED)  # Make it read-only

        back_button = tk.Button(info_window, text="Back", command=info_window.destroy, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.pack(pady=20)

    def update_visual(self):
        self.canvas.delete("all")  # Clear the canvas
        stack_length = self.stack.size()
        if stack_length == 0:
            self.canvas.create_text(200, 150, text="Stack is empty", fill="red", font=("Helvetica", 14))
        else:
            # Draw the stack representation from bottom to top
            for i, item in enumerate(self.stack.items):
                x = 50  # Position for stack (fixed)
                y = 200 - (i * 30)  # Space items vertically from bottom
                self.canvas.create_rectangle(x, y, x + 100, y + 30, fill="#87CEEB", outline="black")
                self.canvas.create_text(x + 50, y + 15, text=item, fill="black", font=("Helvetica", 12))

if __name__ == "__main__":
    root = tk.Tk()
    app = StackGUI(root, lambda: root.destroy())  # Example back callback
    root.mainloop()
