import tkinter as tk
from tkinter import messagebox

class HashTable:
    def __init__(self, size):
        self.size = size
        self.table = [None] * size  # Use a simple array to store values

    def hash_function(self, value):
        """Calculate the hash index based on the ASCII sum of the characters."""
        ascii_sum = sum(ord(char) for char in value)
        return ascii_sum % self.size

    def add(self, value):
        """Add a value to the hash table (overwrites if it already exists)."""
        index = self.hash_function(value)
        self.table[index] = value  # Overwrite the value at the index

    def delete(self, value):
        """Delete a value from the hash table."""
        index = self.hash_function(value)
        if self.table[index] == value:
            self.table[index] = None  # Mark as deleted
            return True
        return False

    def search(self, value):
        """Search for a value in the hash table."""
        index = self.hash_function(value)
        return self.table[index] == value

    def display(self):
        """Return a string representation of the hash table."""
        items = []
        for i in range(self.size):
            if self.table[i] is not None:
                items.append(f"Index {i}: {self.table[i]}")
            else:
                items.append(f"Index {i}: None")
        return "\n".join(items)

class HashTableGUI:
    def __init__(self, root, back_callback):
        self.root = root
        self.hash_table = HashTable(10)  # Hash table size of 10
        self.root.title("Hash Table with Overwriting")
        self.root.configure(bg="#F0F8FF")

        # Set the window size to 1600x1200 and prevent resizing
        self.root.geometry("1600x1200")
        self.root.minsize(1600, 1200)
        self.root.maxsize(1600, 1200)

        # Headline
        heading_label1 = tk.Label(
            root,
            text="SHETH L.U.J COLLEGE AND SIR M.V COLLEGE",
            font=("Helvetica", 24, "bold"),
            bg="#F0F8FF",
            fg="#0000FF"
        )
        heading_label1.pack(pady=(20, 5))

        heading_label2 = tk.Label(
            root,
            text="SIDDHI NAIK S095 DATA STRUCTURE PROJECT",
            font=("Helvetica", 18),
            bg="#F0F8FF",
            fg="#000000"
        )
        heading_label2.pack(pady=(0, 5))

        task_label = tk.Label(
            root,
            text="3. Write a program to implement hash table without collision handling",
            font=("Helvetica", 16),
            bg="#F0F8FF",
            fg="#000000"
        )
        task_label.pack(pady=(0, 20))

        # Create a frame for entry fields
        entry_frame = tk.Frame(root, bg="#F0F8FF")
        entry_frame.pack(pady=10)

        value_label = tk.Label(entry_frame, text="Enter Value:", bg="#F0F8FF", font=("Helvetica", 12))
        value_label.grid(row=0, column=0, padx=5, pady=5)

        self.entry_value = tk.Entry(entry_frame, font=("Helvetica", 16))
        self.entry_value.grid(row=0, column=1, padx=5, pady=5)

        button_frame = tk.Frame(root, bg="#F0F8FF")
        button_frame.pack(pady=10)

        add_button = tk.Button(button_frame, text="Add", command=self.add_item, font=("Helvetica", 16), bg="#87CEEB", fg="black", width=10)
        add_button.grid(row=0, column=0, padx=5)

        delete_button = tk.Button(button_frame, text="Delete", command=self.delete_item, font=("Helvetica", 16), bg="#FF6347", fg="white", width=10)
        delete_button.grid(row=0, column=1, padx=5)

        search_button = tk.Button(button_frame, text="Search", command=self.search_item, font=("Helvetica", 16), bg="#32CD32", fg="white", width=10)
        search_button.grid(row=0, column=2, padx=5)

        back_button = tk.Button(button_frame, text="Back", command=back_callback, font=("Helvetica", 16), bg="#B0E0E6", fg="black", width=10)
        back_button.grid(row=0, column=3, padx=5)

        info_button = tk.Button(button_frame, text="Info", command=self.show_info, font=("Helvetica", 16), bg="#FFD700", fg="black", width=10)
        info_button.grid(row=0, column=4, padx=5)

        self.output = tk.Text(root, width=50, height=10, font=("Helvetica", 12), borderwidth=2, relief="groove")
        self.output.pack(pady=10)

    def add_item(self):
        value = self.entry_value.get()
        if value:
            self.hash_table.add(value)
            index = self.hash_table.hash_function(value)
            self.output.insert(tk.END, f"Added '{value}' at Index {index}\n")
            self.entry_value.delete(0, tk.END)
            self.display_table()
        else:
            messagebox.showwarning("Input Error", "Please enter a value.")

    def delete_item(self):
        value = self.entry_value.get()
        if value:
            if self.hash_table.delete(value):
                self.output.insert(tk.END, f"Deleted '{value}' from the hash table.\n")
            else:
                messagebox.showwarning("Not Found", f"'{value}' not found in the hash table.")
            self.entry_value.delete(0, tk.END)
            self.display_table()
        else:
            messagebox.showwarning("Input Error", "Please enter a value.")

    def search_item(self):
        value = self.entry_value.get()
        if value:
            if self.hash_table.search(value):
                index = self.hash_table.hash_function(value)
                self.output.insert(tk.END, f"Found '{value}' at Index {index}\n")
            else:
                messagebox.showwarning("Not Found", f"'{value}' not found in the hash table.")
            self.entry_value.delete(0, tk.END)
            self.display_table()
        else:
            messagebox.showwarning("Input Error", "Please enter a value.")

    def display_table(self):
        self.output.delete(1.0, tk.END)  # Clear previous output
        self.output.insert(tk.END, "Current Hash Table:\n")
        self.output.insert(tk.END, self.hash_table.display())

    def show_info(self):
        # Create a new window for information
        info_window = tk.Toplevel(self.root)
        info_window.title("Hash Table Information")
        info_window.geometry("1600x1200")  # Set the info window size to 800x600
        info_window.configure(bg="#F0F8FF")

        info_content = (
            "1. A hash table is a data structure that maps keys to values for efficient lookups.\n\n"
            "2. A hash function is used to compute an index from the key, and values are stored in an array.\n\n"
            "3. In this implementation, when a value is added, it is stored at the index computed by the hash function.\n"
            "   - If another value already exists at the same index, it will be overwritten (no collision handling).\n\n"
            "4. This implementation uses no collision handling technique, which means if two keys hash to the same index,\n"
            "   the previous value will be replaced by the new one.\n\n"
            "5. Types of collision handling:\n"
            "   - **Chaining**: Using linked lists to store multiple values at the same index.\n"
            "   - **Open Addressing**: Searching for the next available slot when a collision occurs.\n\n"
            "6. The limitations of this approach are:\n"
            "   - We cannot store multiple values at the same index without overwriting.\n"
            "   - It may lead to data loss in case of hash collisions.\n"
        )

        info_text = tk.Text(info_window, font=("Helvetica", 12), bg="#F0F8FF", fg="green", wrap=tk.WORD, height=20)
        info_text.pack(expand=True, fill='both', padx=10, pady=10)
        info_text.insert(tk.END, info_content)
        info_text.config(state=tk.DISABLED)  # Make the text area read-only

        back_button = tk.Button(info_window, text="Back", command=info_window.destroy, font=("Helvetica", 16), bg="#FF6347", fg="white")
        back_button.pack(pady=10)

# Main application setup
def main():
    root = tk.Tk()
    app = HashTableGUI(root, root.destroy)  # Pass the back function
    root.mainloop()

if __name__ == "__main__":
    main()
